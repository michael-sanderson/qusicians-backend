// middleware/requireSession.js

module.exports = (parseSessionCookie) => (req, res, next) => {
    const parsed = parseSessionCookie(req.cookies.partySession);

    if (!parsed.ok) {
      return res.status(400).json({ error: parsed.error });
    }

    req.sessionCookie = parsed;
    next();
  };
