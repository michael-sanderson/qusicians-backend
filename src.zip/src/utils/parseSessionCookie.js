module.exports = (rawCookie) => {
  if (!rawCookie) {
    return { ok: false, error: "Missing session cookie" };
  }

  try {
    const parsed = JSON.parse(rawCookie);

    if (!parsed?.sessionId) {
      return { ok: false, error: "Invalid session cookie" };
    }

    return {
      ok: true,
      sessionId: parsed.sessionId,
      role: parsed.role ?? null,
      userId: parsed.userId ?? null,
      data: parsed, // full cookie payload if needed
    };

  } catch (err) {
    return { ok: false, error: "Malformed session cookie" };
  }
};
