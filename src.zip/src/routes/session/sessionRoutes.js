module.exports = (express, sessionController) => {
  const router = express.Router();

  router.post("/join", sessionController.joinSessionHandler);

  return router;
};