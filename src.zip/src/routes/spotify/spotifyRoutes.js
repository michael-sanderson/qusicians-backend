module.exports = (express, requireSession, spotifyController) => {
  const router = express.Router();

  // Public routes — no session needed
  router.get("/login", spotifyController.loginHandler);
  router.get("/callback", spotifyController.callbackHandler);

  // Routes that require sessionId
  router.use(requireSession);

  router.get("/queue", spotifyController.getQueueHandler);
  router.get("/search", spotifyController.findTracksHandler);
  router.post('/add', spotifyController.addToQueueHandler);

  return router;
};
