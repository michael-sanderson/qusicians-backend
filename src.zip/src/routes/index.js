// Root router factory — mounts all feature routers
module.exports = ({
  express,
  requireSession,
  sessionController,
  sessionRoutes,
  spotifyController,
  spotifyRoutes,
}) => {
  const router = express.Router();

  // Routes to handle session joining and termination
  router.use(
    "/session",
    sessionRoutes(express, sessionController)
  );

  // Spotify feature API routes
  router.use(
    "/spotify",
    spotifyRoutes(express, requireSession, spotifyController)
  );

  // Catch-all for unmatched routes
  router.use((req, res) => {
    res.status(404).send("Not found");
  });

  return router;
};
