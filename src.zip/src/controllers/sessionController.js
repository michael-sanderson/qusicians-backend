// /controllers/sessionController.js
module.exports = (sessionService, logger) => {
  const joinSessionHandler = (req, res) => {
    // 🔒 EARLY EXIT: already in a session
    if (req.cookies?.partySession) {
      const frontendUrl = process.env.FRONTEND_REDIRECT_URL;
      return res.redirect(`${frontendUrl}/dashboard`);
    }

    const { sessionId } = req.body;
    const name = req.body.name || "Guest";

    if (!sessionId) {
      logger.warn("Join session missing sessionId");
      return res.status(400).send("Missing sessionId");
    }

    sessionService
      .getSession(sessionId)
      .then((session) => sessionService.addGuest(session, name))
      .then((updatedSession) => {
        const cookiePayload = {
          sessionId: updatedSession.sessionId,
          role: "guest",
          displayName: name,
        };

        res.cookie("partySession", JSON.stringify(cookiePayload), {
          httpOnly: false, // matches host flow
          secure: process.env.NODE_ENV === "production",
          sameSite: "lax",
          maxAge: 24 * 60 * 60 * 1000,
          path: "/",
        });

        const frontendUrl = process.env.FRONTEND_REDIRECT_URL;
        return res.redirect(`${frontendUrl}/dashboard`);
      })
      .catch((err) => {
        logger.error({ err, sessionId }, "Failed to join session");
        res.status(500).send("Error joining session");
      });
  };

  return {
    joinSessionHandler,
  };
};
