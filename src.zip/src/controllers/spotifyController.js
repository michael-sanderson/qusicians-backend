// /controllers/spotifyController.js

module.exports = (
  spotifyService,
  spotifyAuthUtil,
  oauthStateService,
  sessionService,
  logger
) => {
  // Redirect user to Spotify OAuth
  const loginHandler = async (req, res) => {
    try {
      const state = await oauthStateService.generateAndStoreState();
      const authUrl = spotifyAuthUtil(state);

      logger.info(
        { state: state.slice(0, 6) + "..." },
        "State generated - redirecting user to Spotify OAuth"
      );

      res.redirect(authUrl);
    } catch (err) {
      logger.error({ err }, "Failed to start Spotify OAuth");
      res.status(500).send("Internal error initiating Spotify OAuth");
    }
  };

  // Spotify OAuth callback
  const callbackHandler = async (req, res) => {
    const code = req.query.code || null;
    const state = req.query.state || null;

    if (!code || !state) {
      logger.warn("Callback missing code or state");
      return res.status(400).send("Missing code or state");
    }

    try {
      const validState = await oauthStateService.verifyAndConsumeState(state);

      if (!validState) {
        logger.warn({ state }, "Invalid or expired OAuth state");
        return res.status(400).send("Invalid state");
      }

      const tokenData = await spotifyService.exchangeCodeForToken(code);

      const hostData = await spotifyService.getCurrentUser(
        tokenData.access_token
      );

      const sessionId = `${hostData.userId}-${state}`;

      const sessionObj = {
        sessionId,
        hostId: hostData.userId,
        hostDisplayName: hostData.displayName,
        hostProfileImageUrl: hostData.profileImageUrl,
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token,
        accessTokenExpiry: Date.now() + tokenData.expires_in * 1000,
      };

      await sessionService.createHostSession(sessionObj);

      logger.debug({ sessionId }, "Host session created");

      const cookiePayload = {
        sessionId,
        role: "host",
        userId: hostData.userId,
        displayName: hostData.displayName,
        profileImageUrl: hostData.profileImageUrl,
      };

      res.cookie("partySession", JSON.stringify(cookiePayload), {
        httpOnly: false,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 24 * 60 * 60 * 1000,
        path: "/",
      });

      const frontendUrl = process.env.FRONTEND_REDIRECT_URL;
      return res.redirect(`${frontendUrl}/dashboard`);
    } catch (err) {
      logger.error({ err }, "Error during Spotify callback handling");
      res.status(500).send("Error processing Spotify callback");
    }
  };

  // Get queue
  const getQueueHandler = (req, res) => {
    const { sessionId } = req.sessionCookie;

    sessionService.getSession(sessionId)
      .then((session) => spotifyService.refreshIfExpired(session, sessionService.persistSession))
      .then((validSession) => spotifyService.getQueue(validSession.accessToken))
      .then((queue) => res.json(queue))
      .catch((err) => {
        logger.error({ err }, "Failed to get Spotify queue");
        res.status(500).json({ error: "Failed to get Spotify queue" });
      });
  };

    // Add Song to queue handler function
  const addToQueueHandler = (req, res) => {
    const { sessionId } = req.sessionCookie;
    const { trackUri } = req.body;

    sessionService.getSession(sessionId)
      .then((session) => spotifyService.refreshIfExpired(session, sessionService.persistSession))
      .then((validSession) => spotifyService.addToQueue(validSession.accessToken, trackUri))
      .then((queue) => res.json(queue))
      .catch((err) => {
        logger.error({ err }, "Failed to add track to Spotify queue");
        res.status(500).json({ error: "Error adding track to Spotify queue" });
      });
  };

  // Track search
  const findTracksHandler = (req, res) => {
    const { sessionId } = req.sessionCookie;
    const searchQuery = req.query;

    sessionService.getSession(sessionId)
      .then((session) => spotifyService.refreshIfExpired(session, sessionService.persistSession))
      .then((validSession) => spotifyService.findTracks(validSession.accessToken, searchQuery))
      .then((tracks) => res.json(tracks))
      .catch((err) => {
        logger.error({ err }, "Failed to perform search for Spotify tracks");
        res.status(500).send("Error fetching tracks from search");
      });
  };

  return {
    loginHandler,
    callbackHandler,
    addToQueueHandler,
    getQueueHandler,
    findTracksHandler,
  };
};
