// server.js

// Load environment variables
require("dotenv").config();

// External libraries
const axios = require("axios");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const { createClient } = require("redis");
const crypto = require("crypto");
const express = require("express");
const pino = require("pino");

// Initialize factories & utils
const C = require("./config/constants");
const createLogger = require("./middleware/logger");
const createRedisClient = require("./data/redisClient");
const createSessionController = require("./controllers/sessionController");
const createSpotifyService = require("./services/spotifyService");
const createSpotifyController = require("./controllers/spotifyController");
const createSpotifyAuthUtil = require("./utils/spotifyAuthUtil");
const createRouter = require("./routes/index");
const createOauthStateService = require("./services/oauthStateService")
const createSessionService = require("./services/sessionService");
const createRequireSession = require("./middleware/requireSession");

// Session Middleware
const parseSessionCookie = require("./utils/parseSessionCookie");
const requireSession = createRequireSession(parseSessionCookie);

// API Routes
const sessionRoutes = require("./routes/session/sessionRoutes")
const spotifyRoutes = require("./routes/spotify/spotifyRoutes");

// Initialize Express
const app = express();
const port = process.env.PORT || 3000;

// Initialize Logger
const logger = createLogger(pino);

// Initialize Redis client and attempt to connect
const redisClient = createRedisClient(createClient, logger);

// Build config object for DI // Args get destructured in service
const config = {
  ...C,
  clientId: process.env.SPOTIFY_CLIENT_ID,
  clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
  redirectUri: process.env.SPOTIFY_REDIRECT_URI,
};

// Initialize  oauthStateService
const oauthStateService = createOauthStateService(
  crypto,
  redisClient,
  C.SESSION_AND_STATE
);

// Initialize session service
const sessionService = createSessionService(
  redisClient,
  logger,
  C.SESSION_AND_STATE
);

// Initialize Spotify service & auth util
const spotifyService = createSpotifyService(axios, config, logger);
const spotifyAuthUtil = createSpotifyAuthUtil(config);

// Initialize Session controller with DI
const sessionController = createSessionController(
  sessionService,
  logger
)

// Initialize Spotify controller with DI
const spotifyController = createSpotifyController(
  spotifyService,
  spotifyAuthUtil,
  oauthStateService,
  sessionService,
  logger
);

// Use CORS
app.use(cors({
  origin: C.CORS_ORIGIN || "http://127.0.0.1:5173",
  credentials: true,
}));

// Use body parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Use Cookie parser (needed to read cookies)
app.use(cookieParser());

// Request logging middleware
app.use((req, res, next) => {
  logger.info({ method: req.method, url: req.url, userAgent: req.headers['user-agent']}) // shows browser, bot, or curl etc. }, "Incoming request");
  next();
});

const routerContext = {
  express,
  requireSession,
  sessionController,
  sessionRoutes,
  spotifyController,
  spotifyRoutes
}

// Mount the routes normally without attaching to "/"
const routes = createRouter(routerContext);
app.use(routes); 

// Start server
app.listen(port, "127.0.0.1", () => {
  console.log(`Server listening on http://127.0.0.1:${port}`);
});
