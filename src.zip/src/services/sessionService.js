// /services/sessionService.js
module.exports = (redisClient, logger, C) => {
  const createHostSession = async (sessionObj) => {
    const session = {
      ...sessionObj,
      createdAt: Date.now(),
      ttl: C.SESSION_TTL_SECONDS,
      guests: []
    };

    await redisClient.setEx(
      C.SESSION_PREFIX + session.sessionId,
      session.ttl,
      JSON.stringify(session)
    );

    logger.info(session.sessionId, "Host session created");
    return session;
  };

  const persistSession = async (session) => {
    await redisClient.setEx(
      C.SESSION_PREFIX + session.sessionId,
      session.ttl || C.SESSION_TTL_SECONDS,
      JSON.stringify(session)
    );
    return session;
  };

  const getSession = async (sessionId) => {
    const session = await redisClient.get(C.SESSION_PREFIX + sessionId);
    if (!session) throw new Error("Session not found");
    return JSON.parse(session);
  };

const addGuest = async (session, name) => {
  const guest = {
    name,
    joinedAt: Date.now(),
  };

  const updatedSession = {
    ...session,
    guests: [...session.guests, guest],
  };

  await persistSession(updatedSession);

  logger.info(
    { sessionId: updatedSession.sessionId, guestName: name },
    "Guest successfully joined session"
  );

  return updatedSession;
};

  return {
    addGuest,
    createHostSession,
    getSession,
    persistSession
  };
};
