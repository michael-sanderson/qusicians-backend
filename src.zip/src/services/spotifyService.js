// Spotify API service factory

module.exports = (axios, config, logger) => {
  // Exchange code for access token
  const exchangeCodeForToken = async (code) => {
    try {
      const payload = new URLSearchParams({
        grant_type: "authorization_code",
        code,
        redirect_uri: config.redirectUri,
        client_id: config.clientId,
        client_secret: config.clientSecret,
      }).toString();

      const res = await axios.request({
        method: "POST",
        url: config.SPOTIFY.TOKEN_URL,
        data: payload,
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
      });

      logger.debug({ code }, "Spotify token exchange successful");
      return res.data;
    } catch (err) {
      logger.error({ err }, "Spotify token exchange failed");
      throw err;
    }
  };

  // Refresh Token
  const refreshAccessToken = async (refreshToken) => {
    const payload = new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      client_id: config.clientId,
      client_secret: config.clientSecret,
    }).toString();

    const res = await axios.request({
      method: "POST",
      url: config.SPOTIFY.TOKEN_URL,
      data: payload,
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });

    logger.debug("Spotify access token refreshed");
    return res.data;
  };

  // Refresh token only if expired
  const refreshIfExpired = async (session, persistSession) => {
    // if still valid, just return as-is
    if (session.accessTokenExpiry > Date.now()) {
      return session;
    }

    logger.debug(
      { sessionId: session.sessionId },
      "Refreshing expired Spotify token"
    );

    const newTokenData = await refreshAccessToken(session.refreshToken);

    logger.info("Spotify access token refreshed");

    const updatedSession = {
      ...session,
      accessToken: newTokenData.access_token,
      accessTokenExpiry: Date.now() + newTokenData.expires_in * 1000,
    };

    await persistSession(updatedSession);
    logger.info("Session updated with new tokens and persisted to Redis");

    return updatedSession;
  };

  // Get current logged-in Spotify user
  const getCurrentUser = async (accessToken) => {
    try {
      const res = await axios.get(`${config.SPOTIFY.API_BASE_URL}/me`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });

      logger.debug({ userId: res.data.id }, "Fetched current Spotify user");

      const hostData = {
        userId: res.data.id,
        profileImageUrl: res.data.images?.[0]?.url || null,
      };

      return hostData;
    } catch (err) {
      logger.error({ err }, "Failed to fetch current Spotify user");
      throw err;
    }
  };

  // Get current playback queue
  const getQueue = async (accessToken) => {
    try {
      const res = await axios.get(
        `${config.SPOTIFY.API_BASE_URL}/me/player/queue`,
        {
          headers: { Authorization: `Bearer ${accessToken}` },
        }
      );

      const { currently_playing, queue } = res.data;

      // Convert track objects consistently
      const nowPlaying = formatTrack(currently_playing);
      const upNext = formatTrack(queue[0]);
      const formattedQueue = queue.map(formatTrack);

      return {
        nowPlaying,
        upNext,
        queue: formattedQueue,
      };
    } catch (err) {
      // Axios-specific info for debugging
      logger.error("Failed to fetch Spotify queue:", {
        message: err.message,
        status: err.response?.status,
        data: err.response?.data,
      });

      throw new Error("Failed to fetch Spotify queue");
    }
  };

  // Add track to queue
  const addToQueue = async (accessToken, trackUri) => {
    try {
      const res = await axios.post(
        `${config.SPOTIFY.API_BASE_URL}/me/player/queue`,
        null, // no body required
        {
          headers: { Authorization: `Bearer ${accessToken}` },
          params: { uri: trackUri },
        }
      );
      logger.info({ trackUri }, "Added track to Spotify queue");
      return res.data;
    } catch (err) {
      logger.error({ err }, "Failed to add track to Spotify queue");
      throw err;
    }
  };

  // Search for Spotify tracks
  const findTracks = async (accessToken, query) => {
    try {
      const q = typeof query === "string" ? query : query.q;

      const res = await axios.get(`${config.SPOTIFY.API_BASE_URL}/search`, {
        headers: { Authorization: `Bearer ${accessToken}` },
        params: { q, type: "track", limit: 50 },
      });
      logger.info({ query }, "Spotify track search successful");
      const formattedTracks = res.data.tracks.items.map(formatTrack);
      return formattedTracks;
    } catch (err) {
      logger.error({ message: err.message, status: err.response?.status, data: err.response?.data }, "Spotify track search failed");
      throw err;
    }
  };

  // HELPER FUNCTION: normalize any Spotify track object into your flat format
  const formatTrack = (track) => {
    if (!track) return null;
    
    return {
      title: track.name,
      artist: track.artists[0].name,
      album: track.album.name,
      artwork: track.album.images[0].url,
      uri: track.uri,
    };
  };

  // Return all services as a plain object
  return {
    exchangeCodeForToken,
    refreshIfExpired,
    getQueue,
    addToQueue,
    findTracks,
    getCurrentUser,
  };
};
