// /services/oauthStateService.js
module.exports = (crypto, redisClient, C) => {
  // Generate and persist OAuth state short-term
  const generateAndStoreState = async () => {
    const newState = crypto.randomBytes(16).toString("hex");
    await redisClient.setEx(
      C.STATE_PREFIX + newState,
      C.STATE_TTL_SECONDS,
      "valid"
    );
    return newState;
  };

  // Validate and consume OAuth state
  const verifyAndConsumeState = async (state) => {
    const key = C.STATE_PREFIX + state;
    const exists = await redisClient.get(key);
    if (!exists) return false;
    await redisClient.del(key);
    return true;
  };

  return {
    generateAndStoreState,
    verifyAndConsumeState
  };
};
