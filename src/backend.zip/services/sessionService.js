module.exports = (redisClient, logger, C) => {
  /* ------------------------------------------------------------------ */
  const sessionKey = (sessionId) =>
    `${C.SESSION_PREFIX}${sessionId}`;

  /* ------------------------------------------------------------------
   * Session lifecycle
   * ------------------------------------------------------------------ */

  const createHostSession = async (sessionObj) => {
    const session = {
      ...sessionObj,
      createdAt: Date.now(),
      ttl: C.SESSION_TTL_SECONDS,
      guests: [],
    };

    await persistSession(session);

    logger.info(
      { sessionId: session.sessionId },
      "Host session created"
    );

    return session;
  };

const getSession = async (sessionId) => {
  const raw = await redisClient.get(sessionKey(sessionId));

  if (!raw) {
    logger.warn({ sessionId }, "Session not found");
    const err = new Error("Session not found");
    throw err;
  }

  return JSON.parse(raw);
};

  /* ------------------------------------------------------------------
   * Join / leave
   * ------------------------------------------------------------------ */

  const joinSession = async (sessionId, name) => {
    const session = await getSession(sessionId);

    const updatedSession = {
      ...session,
      guests: [
        ...session.guests,
        {
          name,
          joinedAt: Date.now(),
        },
      ],
    };

    await persistSession(updatedSession);

    logger.info(
      { sessionId, guestName: name },
      "Guest joined session"
    );

    return {
      sessionId: updatedSession.sessionId,
      role: "guest",
      displayName: name,
    };
  };

  const leaveSession = async (sessionId, displayName) => {
  const session = await getSession(sessionId);

  const updatedSession = {
    ...session,
    guests: session.guests.filter((g) => g.name !== displayName),
  };

  await persistSession(updatedSession);

  logger.info({ sessionId, displayName }, "Guest left session");
  return updatedSession;
};

  const endSession = async (sessionId) => {
  const deletedCount = await redisClient.del(sessionKey(sessionId));
  if (deletedCount === 0) {
    const err = new Error("Session not found");
    throw err;
  }
  logger.info({ sessionId }, "Session ended by host");
  return true;
};

  /* ------------------------------------------------------------------ */

  const persistSession = async (session) => {
    const ttl = session.ttl || C.SESSION_TTL_SECONDS;

    await redisClient.setEx(
      sessionKey(session.sessionId),
      ttl,
      JSON.stringify(session)
    );

    return session;
  };

  /* ------------------------------------------------------------------ */

  return {
    createHostSession,
    getSession,
    joinSession,
    leaveSession,
    endSession,
    persistSession,
  };
};
