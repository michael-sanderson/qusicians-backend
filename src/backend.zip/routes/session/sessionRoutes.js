// routes/session/sessionRoutes.js
//
// Session lifecycle routes.
// Handles joining and leaving a session.

module.exports = (router, sessionController, requireSession) => {
  /* ------------------------------------------------------------------
   * Session entry
   * ------------------------------------------------------------------ */

  router.post("/join", sessionController.joinSessionHandler);

  /* ------------------------------------------------------------------
   * Session exit
   * ------------------------------------------------------------------ */

  router.post("/leave", requireSession, sessionController.leaveSessionHandler);
};
