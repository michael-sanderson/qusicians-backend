module.exports = (
  sessionService,
  setSessionCookie,
  clearSessionCookie,
  logger,
) => {
  /* ------------------------------------------------------------------
   * Join session
   * ------------------------------------------------------------------ */

  const joinSessionHandler = (req, res) => {
    if (req.cookies?.partySession) {
      const frontendUrl = process.env.FRONTEND_REDIRECT_URL;
      return res.redirect(`${frontendUrl}/dashboard`);
    }

    const { sessionId, name = "Guest" } = req.body;

    if (!sessionId) {
      logger.warn("Join session missing sessionId");
      return res.status(400).send("Missing sessionId");
    }

    sessionService
      .joinSession(sessionId, name)
      .then((sessionEnvelope) => {
        setSessionCookie(res, sessionEnvelope);

        const frontendUrl = process.env.FRONTEND_REDIRECT_URL;
        res.redirect(`${frontendUrl}/dashboard`);
      })
      .catch((err) => {
        if (err.message === "Session not found") {
          return res.status(404).send("Session not found");
        }
        logger.error({ err, sessionId }, "Join session failed");
        res.status(500).send("Error joining session");
      });
  };

  /* ------------------------------------------------------------------
   * Leave session
   * ------------------------------------------------------------------ */

  const leaveSessionHandler = async (req, res) => {
    try {
      if (req.userRole === "host" && req.userId === req.session.hostId) {
        await sessionService.endSession(req.session.sessionId);
      } else {
        if (req.displayName) {
          await sessionService.leaveSession(
            req.session.sessionId,
            req.displayName,
          );
        }
        // no displayName: just clear cookie (non-destructive, idempotent)
      }

      clearSessionCookie(res);
      return res.status(204).end();
    } catch (err) {
      if (err.message === "Session not found") {
        clearSessionCookie(res);
        return res.status(204).end();
      }
      logger.error(
        { err, sessionId: req.session?.sessionId },
        "Leave session failed",
      );
      return res.status(500).send("Error leaving session");
    }
  };

  /* ------------------------------------------------------------------ */

  return {
    joinSessionHandler,
    leaveSessionHandler,
  };
};
